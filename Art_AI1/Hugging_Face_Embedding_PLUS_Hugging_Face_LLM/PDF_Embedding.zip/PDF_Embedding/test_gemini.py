import os
import requests
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")
model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash-lite")

if not api_key:
    raise RuntimeError("GEMINI_API_KEY is missing from .env")

url = (
    f"https://generativelanguage.googleapis.com/v1beta/"
    f"models/{model}:generateContent"
)

response = requests.post(
    url,
    params={"key": api_key},
    headers={"Content-Type": "application/json"},
    json={
        "contents": [
            {
                "parts": [
                    {
                        "text": "Reply with exactly: Gemini connection successful"
                    }
                ]
            }
        ]
    },
    timeout=60,
)

if not response.ok:
    print("Status:", response.status_code)
    print("Error:", response.text)
    response.raise_for_status()

data = response.json()
answer = data["candidates"][0]["content"]["parts"][0]["text"]

print(answer)