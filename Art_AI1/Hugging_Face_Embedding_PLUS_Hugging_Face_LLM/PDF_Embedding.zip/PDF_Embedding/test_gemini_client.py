from gemini_client import generate_text


def main():
    answer = generate_text(
        prompt=(
            "In two short sentences, explain how AI can help "
            "an art-history researcher."
        ),
        system_instruction=(
            "You are a concise and careful art-history "
            "research assistant."
        ),
    )

    print("\nGemini client connection successful.\n")
    print(answer)


if __name__ == "__main__":
    main()