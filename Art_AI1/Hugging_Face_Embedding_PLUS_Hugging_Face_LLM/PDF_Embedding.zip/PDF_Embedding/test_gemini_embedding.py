import math

from gemini_embedding import (
    EMBEDDING_DIM,
    embed_document,
    embed_query,
)


def cosine_similarity(
    first_vector,
    second_vector,
):
    return sum(
        first * second
        for first, second in zip(
            first_vector,
            second_vector,
        )
    )


def vector_norm(vector):
    return math.sqrt(
        sum(value * value for value in vector)
    )


def main():
    document = (
        "A photovoltaic cell converts sunlight into "
        "electrical energy using the photovoltaic effect."
    )

    relevant_question = (
        "How does a solar cell produce electricity?"
    )

    unrelated_question = (
        "What techniques were used in Renaissance painting?"
    )

    print("Creating document embedding...")

    document_vector = embed_document(
        document,
        title="Solar Energy Research",
    )

    print("Creating relevant query embedding...")

    relevant_vector = embed_query(
        relevant_question
    )

    print("Creating unrelated query embedding...")

    unrelated_vector = embed_query(
        unrelated_question
    )

    relevant_score = cosine_similarity(
        document_vector,
        relevant_vector,
    )

    unrelated_score = cosine_similarity(
        document_vector,
        unrelated_vector,
    )

    print()
    print("Gemini Embedding test successful.")
    print(f"Expected dimensions: {EMBEDDING_DIM}")
    print(
        f"Actual dimensions: {len(document_vector)}"
    )
    print(
        f"Normalized vector length: "
        f"{vector_norm(document_vector):.6f}"
    )
    print(
        f"Relevant similarity: "
        f"{relevant_score:.4f}"
    )
    print(
        f"Unrelated similarity: "
        f"{unrelated_score:.4f}"
    )

    if len(document_vector) != EMBEDDING_DIM:
        raise RuntimeError(
            "Embedding dimension test failed."
        )

    if relevant_score <= unrelated_score:
        raise RuntimeError(
            "Semantic relevance test failed."
        )


if __name__ == "__main__":
    main()